/**
  ******************************************************************************
  * @file    main.c
  * @author  edison
  * @version V1.0
  * @date    2019-1-17
  * @brief   �������ӿ�
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:STM32 zet6������ 
  * 
  * 
  *
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
 GPIO_InitTypeDef GPIO_InitStructure;
 /**
  * @brief  ������
  * @note   
  * @param  None
  * @retval None
  */
 int main(void)
 {	
	delay_init();	    //��ʱ������ʼ��
    LED_Init();	 
	while(1)
	{
	    LED1_ON 
		LED2_ON
		LED3_ON
		delay_ms(300);	 //��ʱ300ms
	    LED1_OFF
		LED2_OFF
		LED3_OFF
		delay_ms(300);	 //��ʱ300m
	}
 }

 
 /*********************************************END OF FILE**********************/
